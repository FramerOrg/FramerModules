moduleInfo = {
    "author": "r1a",
    "description": "All The Yunhu API Dev Package",
    "hooker": False,
}

from .module import moduleMain
