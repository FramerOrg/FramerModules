import sys


class LogSaver:
    def __init__(self, framer, logger):
        self.redirect_to = framer.env.logsaver_redirect_to
        if framer.env.logsaver_enable:
            sys.stdout = framer.helper.CustomStdout(self.save_file)

    def save_file(self, log_content):
        with open(self.redirect_to, "a", encoding="utf-8") as f:
            f.write(log_content)

        sys.__stdout__.write(log_content)
        sys.__stdout__.flush()
