moduleInfo = {
    "author": "r1a",
    "description": "Redirect Log To File",
    "hooker": True,
}

from .module import moduleMain
