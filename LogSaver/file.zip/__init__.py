moduleInfo = {
    "author": "r1a",
    "description": "A module to redirect logs to a file.",
    "hooker": True,
}

from .saver import LogSaver as moduleMain
