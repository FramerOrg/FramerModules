class ToId:
    def __init__(self, YunhuHTTP, recvIds, recvType):
        self.YunhuHTTP = YunhuHTTP
        self.recvIds = recvIds
        self.recvType = recvType

    def Text(self, content, button=[]):
        return self.YunhuHTTP.post(
            "batch_send",
            {
                "recvIds": self.recvIds,
                "recvType": self.recvType,
                "contentType": "text",
                "content": {"text": content, "buttons": button},
            },
        )

    def Markdown(self, content, button=[]):
        return self.YunhuHTTP.post(
            "batch_send",
            {
                "recvIds": self.recvIds,
                "recvType": self.recvType,
                "contentType": "markdown",
                "content": {"text": content, "buttons": button},
            },
        )

    def Html(self, content, button=[]):
        return self.YunhuHTTP.post(
            "batch_send",
            {
                "recvIds": self.recvIds,
                "recvType": self.recvType,
                "contentType": "html",
                "content": {"text": content, "buttons": button},
            },
        )

    def Image(self, imageType, imageByte, button=[]):
        return self.YunhuHTTP.post(
            "batch_send",
            {
                "recvIds": self.recvIds,
                "recvType": self.recvType,
                "contentType": "image",
                "content": {
                    "imageKey": self.YunhuHTTP.upload("image", imageType, imageByte)[
                        "data"
                    ]["imageKey"],
                    "buttons": button,
                },
            },
        )

    def Video(self, videoType, videoByte, button=[]):
        return self.YunhuHTTP.post(
            "batch_send",
            {
                "recvIds": self.recvIds,
                "recvType": self.recvType,
                "contentType": "video",
                "content": {
                    "videoKey": self.YunhuHTTP.upload("video", videoType, videoByte)[
                        "data"
                    ]["videoKey"],
                    "buttons": button,
                },
            },
        )

    def File(self, fileType, fileByte, button=[]):
        return self.YunhuHTTP.post(
            "batch_send",
            {
                "recvIds": self.recvIds,
                "recvType": self.recvType,
                "contentType": "file",
                "content": {
                    "fileKey": self.YunhuHTTP.upload("file", fileType, fileByte)[
                        "data"
                    ]["fileKey"],
                    "buttons": button,
                },
            },
        )


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

    def To(self, recvType, recvIds):
        return ToId(self.framer.YunhuHTTP, recvIds, recvType)
