moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - Batch Send Module",
    "hooker": False,
}

from .module import moduleMain
