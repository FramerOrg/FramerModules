class MessageSelector:
    def __init__(self, YunhuHTTP, chatId, chatType):
        self.YunhuHTTP = YunhuHTTP
        self.chatId = chatId
        self.chatType = chatType

        self.msgId = ""
        self.before = ""
        self.after = ""

    def WithId(self, msgId):
        self.msgId = msgId
        return self

    def Before(self, before):
        self.before = before
        return self

    def After(self, after):
        self.after = after
        return self

    def Do(self):
        qeury = f"&chat-id={self.chatId}&chat-type={self.chatType}"
        if self.msgId:
            qeury += f"&message-id={self.msgId}"
        if self.before:
            qeury += f"&before={self.before}"
        if self.after:
            qeury += f"&after={self.after}"
        return self.YunhuHTTP.get("messages", qeury)


class MessageController:
    def __init__(self, YunhuHTTP, recvId, recvType):
        self.YunhuHTTP = YunhuHTTP
        self.recvId = recvId
        self.recvType = recvType

    def Recall(self, msgId):
        return self.YunhuHTTP.post(
            "recall", {"msgId": msgId, "chatId": self.recvId, "chatType": self.recvType}
        )

    def Select(self):
        return MessageSelector(self.YunhuHTTP, self.recvId, self.recvType)


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

    def To(self, recvType, recvId):
        return MessageController(self.framer.YunhuHTTP, recvId, recvType)
