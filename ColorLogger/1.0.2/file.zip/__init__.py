moduleInfo = {
    "version": "1.0.2",
    "author": "r1a",
    "description": "A module to log messages with different colors in the console.",
    "hooker": True,
}

from .logger import ColorLogger as moduleMain
