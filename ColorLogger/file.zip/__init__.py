moduleInfo = {
    "author": "r1a",
    "description": "A module to log messages with different colors in the console.",
    "hooker": True,
}

from .module import moduleMain
