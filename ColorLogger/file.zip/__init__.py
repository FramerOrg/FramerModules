moduleInfo = {
    "author": "r1a",
    "description": "Log Message With Color",
    "hooker": True,
}

from .module import moduleMain
