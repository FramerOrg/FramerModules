class SendMessage:
    def __init__(self, framer, logger):
        logger("SendMessage module loaded")