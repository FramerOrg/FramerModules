class SendMessageCLI:
    def __init__(self, args):
        print("- SendMessageCLI Args:")
        print("-", args)
