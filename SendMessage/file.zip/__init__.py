moduleInfo = {
    "author": "r1a",
    "description": "Send a message to a specified user or group",
}

from .module import SendMessage as moduleMain
from .cli import SendMessageCLI as cliMain
