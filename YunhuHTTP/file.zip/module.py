import io
import mimetypes
import requests
import http.client
import json


class ChunkedTransfer:
    def __init__(self, path):
        self.path = path
        self.headers_sent = False

        # create HTTPS
        self.connection = http.client.HTTPSConnection("chat-go.jwzhd.com")
        if not self.connection:
            raise http.client.HTTPException("Connection not established")

    def Send(self, data):
        # init request
        if not self.headers_sent:
            self.connection.putrequest("POST", self.path)
            self.connection.putheader("Transfer-Encoding", "chunked")
            self.connection.putheader("Content-Type", "text/plain; charset=utf-8")
            self.connection.endheaders()
            self.headers_sent = True

        # do not send empty data
        if not data:
            return

        # make sure data is bytes
        if isinstance(data, str):
            data = data.encode("utf-8")

        # send data: length + \r\n + data + \r\n
        chunk = f"{len(data):X}\r\n".encode() + data + b"\r\n"
        self.connection.send(chunk)

    def Close(self):
        try:
            if self.headers_sent:
                self.connection.send(b"0\r\n\r\n")
            response = self.connection.getresponse()
            return json.loads(response.read().decode("utf-8"))
        finally:
            self.connection.close()


class moduleMain:
    def __init__(self, framer, logger):
        self.yunhu_token = framer.env.yunhu_token
        self.api_prefix = "https://chat-go.jwzhd.com/open-apis/v1"

    def post(self, api_name, data):
        return requests.post(
            url=f"{self.api_prefix}/bot/{api_name}?token={self.yunhu_token}",
            headers={"Content-Type": "application/json; charset=utf-8"},
            json=data,
        ).json()

    def upload(self, upload_type, file_type, file_data):
        file_name = f"{upload_type}.{file_type}"
        return requests.post(
            url=f"{self.api_prefix}/{upload_type}/upload?token={self.yunhu_token}",
            files=[
                (
                    upload_type,
                    (
                        file_name,
                        io.BufferedReader(io.BytesIO(file_data)),
                        mimetypes.guess_type(file_name),
                    ),
                )
            ],
        ).json()

    def stream(self, recvId, recvType, contentType):
        return ChunkedTransfer(
            "{}/bot/send-stream?token={}&recvId={}&recvType={}&contentType={}".format(
                self.api_prefix, self.yunhu_token, recvId, recvType, contentType
            )
        )
