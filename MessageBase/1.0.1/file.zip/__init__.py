moduleInfo = {
    "version": "1.0.1",
    "author": "r1a",
    "description": "Base class for Yunhu Message API",
}

from .module import MessageBase as moduleMain
