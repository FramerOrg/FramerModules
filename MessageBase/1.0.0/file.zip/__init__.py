moduleInfo = {
    "version": "1.0.0",
    "author": "r1a",
    "description": "Base class for Yunhu Message API",
}

from .module import MessageBase as moduleMain
