moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Command Message Handler",
    "hooker": False,
}

from .module import moduleMain
