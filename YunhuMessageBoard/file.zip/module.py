class UserBoard:
    def __init__(self, YunhuHTTP, recvId, recvType):
        self.YunhuHTTP = YunhuHTTP
        self.recvId = recvId
        self.recvType = recvType

    def Text(self, content, to_member="", expire=0):
        return self.YunhuHTTP.post(
            "board",
            {
                "chatId": self.recvId,
                "chatType": self.recvType,
                "contentType": "text",
                "content": content,
                "memberId": to_member,
                "expireTime": expire,
            },
        )

    def Markdown(self, content, to_member="", expire=0):
        return self.YunhuHTTP.post(
            "board",
            {
                "chatId": self.recvId,
                "chatType": self.recvType,
                "contentType": "markdown",
                "content": content,
                "memberId": to_member,
                "expireTime": expire,
            },
        )

    def Html(self, content, to_member="", expire=0):
        return self.YunhuHTTP.post(
            "board",
            {
                "chatId": self.recvId,
                "chatType": self.recvType,
                "contentType": "html",
                "content": content,
                "memberId": to_member,
                "expireTime": expire,
            },
        )

    def Cancel(self, to_member=""):
        return self.YunhuHTTP.post(
            "board-dismiss",
            {"chatId": self.recvId, "chatType": self.recvType, "memberId": to_member},
        )


class GlobalBoard:
    def __init__(self, YunhuHTTP):
        self.YunhuHTTP = YunhuHTTP

    def Text(self, content, expire=0):
        return self.YunhuHTTP.post(
            "board-all",
            {
                "contentType": "text",
                "content": content,
                "expireTime": expire,
            },
        )

    def Markdown(self, content, expire=0):
        return self.YunhuHTTP.post(
            "board-all",
            {
                "contentType": "markdown",
                "content": content,
                "expireTime": expire,
            },
        )

    def Html(self, content, expire=0):
        return self.YunhuHTTP.post(
            "board-all",
            {
                "contentType": "html",
                "content": content,
                "expireTime": expire,
            },
        )

    def Cancel(self):
        return self.YunhuHTTP.post("board-all-dismiss", {})


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

    def To(self, recvType, recvId):
        return UserBoard(self.framer.YunhuHTTP, recvId, recvType)

    def All(self):
        return GlobalBoard(self.framer.YunhuHTTP)
