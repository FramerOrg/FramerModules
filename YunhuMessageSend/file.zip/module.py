class ToId:
    def __init__(self, YunhuHTTP, recvId, recvType):
        self.YunhuHTTP = YunhuHTTP
        self.recvId = recvId
        self.recvType = recvType

    def Text(self, content, button=[], parentId=""):
        return self.YunhuHTTP.post(
            "send",
            {
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "text",
                "content": {"text": content, "buttons": button},
                "parentId": parentId,
            },
        )

    def Markdown(self, content, button=[], parentId=""):
        return self.YunhuHTTP.post(
            "send",
            {
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "markdown",
                "content": {"text": content, "buttons": button},
                "parentId": parentId,
            },
        )

    def Html(self, content, button=[], parentId=""):
        return self.YunhuHTTP.post(
            "send",
            {
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "html",
                "content": {"text": content, "buttons": button},
                "parentId": parentId,
            },
        )

    def Image(self, imageType, imageByte, button=[], parentId=""):
        return self.YunhuHTTP.post(
            "send",
            {
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "image",
                "content": {
                    "imageKey": self.YunhuHTTP.upload("image", imageType, imageByte)[
                        "data"
                    ]["imageKey"],
                    "buttons": button,
                },
                "parentId": parentId,
            },
        )

    def Video(self, videoType, videoByte, button=[], parentId=""):
        return self.YunhuHTTP.post(
            "send",
            {
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "video",
                "content": {
                    "videoKey": self.YunhuHTTP.upload("video", videoType, videoByte)[
                        "data"
                    ]["videoKey"],
                    "buttons": button,
                },
                "parentId": parentId,
            },
        )

    def File(self, fileType, fileByte, button=[], parentId=""):
        return self.YunhuHTTP.post(
            "send",
            {
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "file",
                "content": {
                    "fileKey": self.YunhuHTTP.upload("file", fileType, fileByte)[
                        "data"
                    ]["fileKey"],
                    "buttons": button,
                },
                "parentId": parentId,
            },
        )


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

    def To(self, recvType, recvId):
        return ToId(self.framer.YunhuHTTP, recvId, recvType)
