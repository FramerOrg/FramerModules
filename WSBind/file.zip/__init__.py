moduleInfo = {
    "author": "r1a",
    "description": "Bind WebSocket To HTTP POST Request",
    "hooker": False,
}

from .module import moduleMain
