import time
import requests
from websocket import WebSocketApp


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger
        self.running = False
        self.ws_instances = {}

    def __call__(self, config):
        self.running = True
        for ws_url, http_url in config.items():
            self.logger(f"Bind {ws_url} -> {http_url}")
            self.framer.Backend(self._ws_worker, ws_url, http_url)

    def _ws_worker(self, ws_url, http_url):
        while self.running:
            try:
                self.logger(f"Connecting to WebSocket: {ws_url}")
                ws = WebSocketApp(
                    ws_url,
                    on_open=lambda ws: self._on_open(ws_url, ws),
                    on_message=lambda ws, msg: self._on_message(msg, http_url),
                    on_error=lambda ws, err: self._on_error(ws_url, err),
                    on_close=lambda ws, status, msg: self._on_close(
                        ws_url, status, msg
                    ),
                )
                self.ws_instances[ws_url] = ws
                ws.run_forever()
            except Exception as e:
                self.logger(f"Unexpected error: {e}")

            if not self.running:
                break

            self.logger(f"Reconnecting to {ws_url} immediately...")
            time.sleep(0.1)

    def _on_open(self, ws_url, ws):
        self.logger(f"WebSocket connected: {ws_url}")
        self.ws_instances[ws_url] = ws

    def _on_message(self, message, http_url):
        try:
            response = requests.post(http_url, data=message, timeout=5)
            if not response.ok:
                self.logger(f"HTTP POST failed ({http_url}): {response.status_code}")
        except Exception as e:
            self.logger(f"HTTP POST error ({http_url}): {str(e)}")

    def _on_error(self, ws_url, error):
        self.logger(f"WebSocket error ({ws_url}): {str(error)}")
        if ws_url in self.ws_instances:
            self.ws_instances[ws_url].close()

    def _on_close(self, ws_url, status_code, close_msg):
        self.logger(f"WebSocket closed ({ws_url}): [{status_code}] {close_msg or ''}")
        if ws_url in self.ws_instances:
            del self.ws_instances[ws_url]
