from .epc import sdk as epc


class Epsdk:
    def __init__(self, framer, logger):
        epc.init()
        framer.sdk = epc
