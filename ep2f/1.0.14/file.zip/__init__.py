moduleInfo = {
    "version": "1.0.14",
    "author": "r1a, wsu2059",
    "description": "erispulse custom core",
    "hooker": True,
}

from .epsdk import Epsdk as moduleMain
