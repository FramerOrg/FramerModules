import threading
from typing import List, Dict, Any, Callable


class moduleMain:
    def __init__(self, framer, logger):
        self.logger = logger
        self.threads: List[threading.Thread] = []
        self.flags: Dict[str, threading.Event] = {}
        self.condition = threading.Condition()

    def New(self, id_: str, trigger: Callable[[], Any], *pipes: Callable) -> None:
        self.flags[id_] = threading.Event()
        pipes_list = list(pipes)

        def process_step(v_in: Any, step: int) -> None:
            if step >= len(pipes_list) or self.flags[id_].is_set():
                return

            def next_callback(v_out: Any) -> None:
                process_step(v_out, step + 1)

            pipes_list[step](
                v_in,
                next_callback,
                lambda v: self.logger(f"Pipeline {id_} Resolve: {v}"),
                lambda v: self.logger(f"Pipeline {id_} Reject: {v}"),
            )

        def listen() -> None:
            while not self.flags[id_].is_set():
                with self.condition:
                    if (v_in := trigger()) is None:
                        self.condition.wait(0.1)
                        continue

                process_step(v_in, 0)

        t = threading.Thread(target=listen, name=f"Pipe-{id_}", daemon=True)
        self.threads.append(t)
        t.start()

    def StopAll(self, timeout: float = 2.0) -> None:
        self.logger("Stopping All Pipelines")
        for flag in self.flags.values():
            flag.set()

        with self.condition:
            self.condition.notify_all()

        for t in self.threads:
            t.join(timeout)
            if t.is_alive():
                self.logger(f"Warning: Stop {t.name} Timeout")
