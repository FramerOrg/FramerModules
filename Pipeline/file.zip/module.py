import threading
from typing import List, Dict, Any


class moduleMain:
    def __init__(self, framer, logger):
        self.logger = logger

        self.threads: List[threading.Thread] = []
        self.flags: Dict[str, threading.Event] = {}
        self.condition = threading.Condition()

    def New(self, id_: str, trigger: Any, *pipes: Any) -> None:
        self.flags[id_] = threading.Event()
        pipes_list = list(pipes)

        def process_step(v_in: Any, step: int) -> None:
            if step >= len(pipes_list) or self.flags[id_].is_set():
                return

            current_pipe = pipes_list[step]

            def return_next(v_out: Any) -> None:
                process_step(v_out, step + 1)

            def resolve(v_out: Any) -> None:
                self.logger("Pipeline {} Resolve: {}".format(id_, v_out))

            def reject(v_out: Any) -> None:
                self.logger("Pipeline {} Reject: {}".format(id_, v_out))

            current_pipe.Pipe(v_in, return_next, resolve, reject)

        def listen() -> None:
            while not self.flags[id_].is_set():
                with self.condition:
                    v_in = trigger.Trigger()
                    if v_in is None:
                        self.condition.wait(0.1)
                        continue

                process_step(v_in, 0)

        t = threading.Thread(target=listen, name=f"PipelineThread-{id_}")
        self.threads.append(t)
        t.start()

    def StopAll(self, timeout: float = 2.0) -> None:
        self.logger("Stopping All Pipelines")
        for id_ in self.flags:
            self.flags[id_].set()

        with self.condition:
            self.condition.notify_all()

        for t in self.threads:
            t.join(timeout)
            if t.is_alive():
                self.logger("Warning: Stop {} Timeout".format(t.name))
