moduleInfo = {
    "author": "r1a",
    "description": "Framer Pipeline Support",
    "hooker": False,
}

from .module import moduleMain
