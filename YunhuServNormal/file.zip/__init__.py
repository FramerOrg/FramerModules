moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Normal Message Handler",
    "hooker": False,
}

from .module import moduleMain
