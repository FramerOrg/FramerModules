moduleInfo = {
    "author": "r1a",
    "description": "Framer Multithreading Package",
    "hooker": False,
}

from .module import moduleMain
