import sys
import threading


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

        self.threads = []

    def __call__(self, func, *args, **kwargs):
        t = threading.Thread(target=func, args=args, kwargs=kwargs, daemon=True)
        self.threads.append(t)
        t.start()

    def Loop(self):
        try:
            while True:
                if len(self.threads) == 0:
                    break
                for t in self.threads:
                    if not t.is_alive():
                        self.threads.remove(t)
        except KeyboardInterrupt:
            self.logger("KeyboardInterrupt")
            sys.exit(0)
