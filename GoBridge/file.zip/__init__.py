moduleInfo = {
    "author": "r1a",
    "description": "Go Import support for Framer",
    "hooker": True,
}

from .module import moduleMain
