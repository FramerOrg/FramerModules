import sys
import os
import subprocess
import ctypes
from importlib.abc import MetaPathFinder, Loader
from importlib.machinery import ModuleSpec


class GoLoader(Loader):
    def __init__(self, so_path, fullname):
        self.so_path = so_path
        self.fullname = fullname

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        # load library
        lib = ctypes.cdll.LoadLibrary(self.so_path)

        # dynamic function getter
        def get_lib_attr(name):
            return getattr(lib, name)

        # bind to module
        module.__getattr__ = get_lib_attr


class GoFinder(MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        # get import module name
        module_name = fullname.split(".")[-1]

        # go file search path
        search_paths = sys.path if path is None else path
        for base_path in search_paths:

            # possible file paths
            py_path = os.path.join(base_path, f"{module_name}.py")
            go_path = os.path.join(base_path, f"{module_name}.go")
            so_path = os.path.join(base_path, f"{module_name}.so")

            # ignore python file
            if os.path.isfile(py_path):
                continue

            # process go file
            if os.path.isfile(go_path):

                # ensure newest compiled
                self._ensure_compiled(go_path, so_path)

                # custom module loader
                loader = GoLoader(so_path, fullname)

                # create module spec
                return ModuleSpec(
                    name=fullname, loader=loader, origin=go_path, is_package=True
                )
        return None

    def _ensure_compiled(self, go_path, so_path):
        # build if so file old
        if not os.path.exists(so_path) or (
            os.path.getmtime(go_path) > os.path.getmtime(so_path)
        ):

            # compile go file
            self._compile_go(go_path, so_path)

    def _compile_go(self, go_path, so_path):
        # build command
        cmd = ["go", "build", "-buildmode=c-shared", "-o", so_path, go_path]

        # run command
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            self.logger(f"Compiled {go_path} -> {so_path}")
            if result.stderr:
                self.logger("Compiler warnings: " + result.stderr)

        # catch errors
        except subprocess.CalledProcessError as e:
            raise ImportError(
                f"Go compilation failed for {go_path}:\n"
                f"Exit code: {e.returncode}\n"
                f"Error: {e.stderr}"
            ) from e

        # if go not installed
        except FileNotFoundError:
            raise ImportError("Go compiler not found. Install from https://golang.org/")

    def logger(self, message):
        pass


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

        # init go finder
        finder = GoFinder()

        # add logger
        finder.logger = self.logger

        # add to meta path
        sys.meta_path.insert(0, finder)
