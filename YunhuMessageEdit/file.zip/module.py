class Editor:
    def __init__(self, YunhuHTTP, recvId, recvType, msgId):
        self.YunhuHTTP = YunhuHTTP
        self.recvId = recvId
        self.recvType = recvType
        self.msgId = msgId

    def NewText(self, content, button=[]):
        return self.YunhuHTTP.post(
            "edit",
            {
                "msgId": self.msgId,
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "text",
                "content": {"text": content, "buttons": button},
            },
        )

    def NewMarkdown(self, content, button=[]):
        return self.YunhuHTTP.post(
            "edit",
            {
                "msgId": self.msgId,
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "markdown",
                "content": {"text": content, "buttons": button},
            },
        )

    def NewHtml(self, content, button=[]):
        return self.YunhuHTTP.post(
            "edit",
            {
                "msgId": self.msgId,
                "recvId": self.recvId,
                "recvType": self.recvType,
                "contentType": "html",
                "content": {"text": content, "buttons": button},
            },
        )


class WithMsgId:
    def __init__(self, YunhuHTTP, recvId, recvType):
        self.YunhuHTTP = YunhuHTTP
        self.recvId = recvId
        self.recvType = recvType

    def WithId(self, msgId):
        return Editor(self.YunhuHTTP, self.recvId, self.recvType, msgId)


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

    def To(self, recvType, recvId):
        return WithMsgId(self.framer.YunhuHTTP, recvId, recvType)
