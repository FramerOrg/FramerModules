moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - Message Edit Module",
    "hooker": False,
}

from .module import moduleMain
