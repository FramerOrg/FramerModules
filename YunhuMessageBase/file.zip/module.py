class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger
