moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Group Leave Message Handler",
    "hooker": False,
}

from .module import moduleMain
