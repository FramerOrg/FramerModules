moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Bot UnFollow Message Handler",
    "hooker": False,
}

from .module import moduleMain
